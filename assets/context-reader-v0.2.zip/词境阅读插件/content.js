(() => {
  if (globalThis.__contextReaderInstalled) return;
  globalThis.__contextReaderInstalled = true;
  let host = null, timer = null, sequence = 0, mode = 'auto', enabled = true, repositionCurrent = null;
  let lastSignature = '';
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  function readableText(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(text) {
        const parent = text.parentElement;
        if (parent?.closest('script,style,noscript,input,textarea,select,[hidden],[aria-hidden="true"],[contenteditable]:not([contenteditable="false"]),[data-context-reader]')) return NodeFilter.FILTER_REJECT;
        if (parent?.isConnected) {
          const style = getComputedStyle(parent);
          if (style.visibility === 'hidden' || style.display === 'none' || (!parent.getClientRects().length && style.display !== 'contents')) return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let text = '', current;
    while ((current = walker.nextNode())) text += current.nodeValue;
    return normalize(text);
  }
  const call = async message => {
    const result = await chrome.runtime.sendMessage(message);
    if (!result?.ok) throw new Error(result?.error || '扩展连接中断，请刷新网页后重新启用。');
    return result.data;
  };
  const updateSettings = () => call({type: 'PUBLIC_SETTINGS'}).then(s => { mode = s.lookupMode; }).catch(() => {});
  updateSettings();

  function captureSelection() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount !== 1) return null;
    const range = selection.getRangeAt(0);
    const anchor = range.startContainer.nodeType === Node.ELEMENT_NODE ? range.startContainer : range.startContainer.parentElement;
    const end = range.endContainer.nodeType === Node.ELEMENT_NODE ? range.endContainer : range.endContainer.parentElement;
    if (!anchor || !end || anchor.closest('input,textarea,[contenteditable]:not([contenteditable="false"]),[data-context-reader]') || end.closest('input,textarea,[contenteditable]:not([contenteditable="false"])')) return null;
    const word = normalize(selection.toString());
    if (word.length > 90 || !/^[A-Za-z][A-Za-z\s'’\-]*$/.test(word) || word.split(/\s+/).length > 6) return null;
    let block = anchor.closest('p,li,blockquote,td,h1,h2,h3,h4,h5,h6,pre');
    if (!block) {
      block = anchor;
      while (block.parentElement && block !== document.body && (readableText(block).length < 100 || ['inline', 'contents'].includes(getComputedStyle(block).display))) block = block.parentElement;
    }
    if (!block.contains(end)) return null;
    const whole = readableText(block);
    const prefix = document.createRange(); prefix.selectNodeContents(block); prefix.setEnd(range.startContainer, range.startOffset);
    const estimate = readableText(prefix.cloneContents()).length;
    const offset = whole.toLowerCase().indexOf(word.toLowerCase(), Math.max(0, estimate - 1));
    if (offset < 0) return null;
    const pieces = Array.from(new Intl.Segmenter('en', {granularity: 'sentence'}).segment(whole));
    const selectedPieces = pieces.filter(p => p.index <= offset + word.length - 1 && p.index + p.segment.length > offset);
    let sentenceStart = selectedPieces[0]?.index || 0;
    let sentence = selectedPieces.map(p => p.segment).join('').trim();
    if (!sentence) sentence = whole;
    // Very long unpunctuated blocks are clipped around the selected occurrence, never from the page start.
    if (sentence.length > 1600) { sentenceStart = Math.max(0, offset - 650); sentence = whole.slice(sentenceStart, offset + word.length + 800); }
    const blocks = Array.from(document.querySelectorAll('p,li,h1,h2,h3,h4,h5,h6,blockquote'))
      .filter(el => el !== block && !el.contains(block) && !block.contains(el) && el.getClientRects().length && !el.closest('[data-context-reader]') && readableText(el).length > 15);
    const before = blocks.filter(el => el.compareDocumentPosition(block) & Node.DOCUMENT_POSITION_FOLLOWING).slice(-2).map(el => readableText(el).slice(-800));
    const after = blocks.filter(el => el.compareDocumentPosition(block) & Node.DOCUMENT_POSITION_PRECEDING).slice(0, 1).map(el => readableText(el).slice(0, 700));
    const local = whole.slice(Math.max(0, offset - 1300), offset + word.length + 1400);
    const context = [...before, local, ...after].join('\n\n').slice(0, 5000);
    const rect = range.getBoundingClientRect();
    const paragraphRect = block.getBoundingClientRect();
    return {word, sentence, context, selectionStart: offset - sentenceStart, title: document.title, url: location.href,
      rect: {left: rect.left, top: rect.top, bottom: rect.bottom},
      paragraphRect: {top: paragraphRect.top, bottom: paragraphRect.bottom}, anchorRange: range.cloneRange(), blockElement: block};
  }

  function hide() { if (host) { host.remove(); host = null; } repositionCurrent = null; sequence++; }
  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function show(capture) {
    if (host) host.remove();
    host = document.createElement('div'); host.dataset.contextReader = '';
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;width:min(386px,calc(100vw - 24px));font-size:14px;';
    const shadow = host.attachShadow({mode: 'open'});
    const panel = host;
    let manualPosition = null, drag = null;
    const style = element('style');
    style.textContent = `:host{color-scheme:light}*{box-sizing:border-box}article{font:14px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;color:#243b36;background:#fffefb;border:1px solid #cddbd4;border-radius:16px;box-shadow:0 12px 42px #153c3329;overflow:hidden}header{display:flex;align-items:center;justify-content:space-between;padding:13px 17px;background:#f0f5ef;border-bottom:1px solid #e1e9df}.brand{font-size:11px;letter-spacing:.13em;color:#5e7568}h2{margin:3px 0 0;font-family:Georgia,serif;font-size:25px;font-weight:500;color:#193f34}.body{padding:16px 18px;max-height:min(58vh,500px);overflow:auto}p{margin:0 0 10px;white-space:pre-wrap;overflow-wrap:anywhere}.meaning{font-size:17px;font-weight:650;color:#194e3f}.label{font-size:11px;font-weight:700;letter-spacing:.08em;color:#71837a;margin:13px 0 4px}.muted{font-size:12px;color:#6e7f77}.error{color:#a4432f}.tip{padding:10px 12px;background:#f4f3e9;border-radius:8px}.footer{padding:11px 17px;display:flex;justify-content:space-between;align-items:center;border-top:1px solid #e4e9e0;gap:10px}.saved{font-size:11px;color:#527463}button{font:inherit;cursor:pointer;border:0;border-radius:7px;padding:5px 9px;background:#e7eee7;color:#225c48}button:focus-visible{outline:2px solid #b97732;outline-offset:2px}button:hover{background:#dce8dc}.close{font-size:21px;line-height:1;background:transparent}.primary{background:#215b46;color:white;padding:8px 12px}.source{font-size:11px;color:#93856c}`;
    shadow.append(style);
    const movingStyle = element('style');
    movingStyle.textContent = 'article{display:flex;flex-direction:column;max-height:calc(100vh - 24px)}header,.footer{flex-shrink:0}header{cursor:grab;user-select:none;touch-action:none}header.dragging{cursor:grabbing}header:focus-visible{outline:2px solid #b97732;outline-offset:-3px}.body{min-height:0;flex-shrink:1}.drag-hint{font-size:10px;letter-spacing:0;color:#738776;margin-left:9px}.close{cursor:pointer}';
    shadow.append(movingStyle);
    const article = element('article'); article.setAttribute('role', 'dialog'); article.setAttribute('aria-label', '词境语境释义');
    const header = element('header'); const heading = element('div'); heading.append(element('div', '词境 / IN CONTEXT', 'brand'), element('h2', capture.word));
    heading.firstChild.append(element('span', '拖动移动', 'drag-hint'));
    header.tabIndex = 0; header.setAttribute('aria-label', '移动释义卡片：拖动或使用方向键');
    header.title = '拖动此处移动卡片；键盘聚焦后可用方向键移动';
    const close = element('button', '×', 'close'); close.setAttribute('aria-label', '关闭释义'); close.addEventListener('click', hide);
    header.append(heading, close); const body = element('div', undefined, 'body'); body.setAttribute('aria-live', 'polite');
    article.append(header, body); shadow.append(article); document.documentElement.append(host);
    const clamp = (value, min, max) => Math.max(min, Math.min(value, Math.max(min, max)));
    const margin = 12, gap = 10;
    function position() {
      if (host !== panel || !panel.isConnected) return;
      const viewportHeight = Math.max(1, innerHeight - margin * 2);
      if (manualPosition) {
        // Keep the header where the reader put it even when an asynchronous answer makes the card taller.
        const minVisible = Math.min(viewportHeight, header.getBoundingClientRect().height + 85);
        const top = clamp(manualPosition.top, margin, innerHeight - margin - minVisible);
        article.style.maxHeight = `${Math.max(1, innerHeight - margin - top)}px`;
        const left = clamp(manualPosition.left, margin, innerWidth - panel.offsetWidth - margin);
        panel.style.left = `${left}px`; panel.style.top = `${top}px`;
        manualPosition = {left, top}; panel.dataset.placement = 'manual'; return;
      }
      const anchor = capture.blockElement?.isConnected ? capture.anchorRange.getBoundingClientRect() : capture.rect;
      const paragraph = capture.blockElement?.isConnected ? capture.blockElement.getBoundingClientRect() : capture.paragraphRect;
      if (anchor.bottom < 0 || anchor.top > innerHeight) { hide(); return; }
      article.style.maxHeight = `${viewportHeight}px`;
      const naturalHeight = panel.getBoundingClientRect().height;
      const minUsefulHeight = Math.min(viewportHeight, header.getBoundingClientRect().height + (article.querySelector('.footer')?.offsetHeight || 0) + 80);
      const candidates = rect => [
        {side: 'above', edge: rect.top - gap, space: rect.top - gap - margin},
        {side: 'below', edge: rect.bottom + gap, space: innerHeight - margin - rect.bottom - gap}
      ];
      const paragraphOptions = candidates(paragraph || anchor);
      let choice = paragraphOptions.find(c => c.space >= naturalHeight)
        || paragraphOptions.filter(c => c.space >= minUsefulHeight).sort((a, b) => b.space - a.space)[0];
      if (!choice) {
        const wordOptions = candidates(anchor);
        choice = wordOptions.find(c => c.space >= naturalHeight) || wordOptions.sort((a, b) => b.space - a.space)[0];
      }
      article.style.maxHeight = `${Math.min(viewportHeight, Math.max(minUsefulHeight, choice.space))}px`;
      const height = panel.getBoundingClientRect().height;
      const top = clamp(choice.side === 'above' ? choice.edge - height : choice.edge, margin, innerHeight - height - margin);
      panel.style.left = `${clamp(anchor.left, margin, innerWidth - panel.offsetWidth - margin)}px`;
      panel.style.top = `${top}px`; panel.dataset.placement = choice.side;
    }
    function moveTo(left, top) {
      const bounds = panel.getBoundingClientRect();
      manualPosition = {left: clamp(left, margin, innerWidth - bounds.width - margin), top: clamp(top, margin, innerHeight - bounds.height - margin)};
      position();
    }
    header.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const bounds = panel.getBoundingClientRect();
      drag = {id: event.pointerId, x: event.clientX, y: event.clientY, left: bounds.left, top: bounds.top};
      header.setPointerCapture(event.pointerId); header.classList.add('dragging');
    });
    header.addEventListener('pointermove', event => {
      if (!drag || drag.id !== event.pointerId) return;
      event.preventDefault(); moveTo(drag.left + event.clientX - drag.x, drag.top + event.clientY - drag.y);
    });
    const endDrag = event => {
      if (!drag || event.pointerId !== drag.id) return;
      drag = null; header.classList.remove('dragging');
      if (header.hasPointerCapture(event.pointerId)) header.releasePointerCapture(event.pointerId);
    };
    header.addEventListener('pointerup', endDrag); header.addEventListener('pointercancel', endDrag); header.addEventListener('lostpointercapture', endDrag);
    header.addEventListener('keydown', event => {
      const directions = {ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1]};
      if (event.target !== header || !directions[event.key]) return;
      event.preventDefault(); event.stopPropagation();
      const bounds = panel.getBoundingClientRect(), [x, y] = directions[event.key], step = event.shiftKey ? 40 : 16;
      moveTo(bounds.left + x * step, bounds.top + y * step);
    });
    repositionCurrent = position;
    position();
    return {body, article, position};
  }

  async function explainSelection(capture) {
    if (!capture) return;
    const current = ++sequence;
    const ui = show(capture);
    ui.body.append(element('p', '正在结合前后文理解…', 'muted'));
    ui.position();
    try {
      const {rect, paragraphRect, anchorRange, blockElement, ...payload} = capture;
      const result = await call({type: 'LOOKUP', capture: payload});
      if (current !== sequence || !host) return;
      const e = result.card.explanation; ui.body.replaceChildren();
      ui.body.append(element('p', e.meaning, 'meaning'));
      if (e.partOfSpeech) ui.body.append(element('p', e.partOfSpeech, 'muted'));
      if (e.uncertain) ui.body.append(element('p', '上下文可能不足，请结合原文核对。', 'source'));
      for (const [label, text] of [['本句意思', e.translation], ['为什么这样理解', e.explanation], ['这里指的是', e.reference]]) {
        if (text) ui.body.append(element('div', label, 'label'), element('p', text));
      }
      if (e.memoryTip) ui.body.append(element('p', e.memoryTip, 'tip'));
      const footer = element('div', undefined, 'footer');
      footer.append(element('span', result.saved ? (result.cached ? '已记录 · 使用已保存释义' : '已自动加入复习') : result.warning, result.saved ? 'saved' : 'error'));
      const library = element('button', '去复习'); library.addEventListener('click', () => call({type: 'OPEN_APP'}).catch(() => {}));
      footer.append(library); ui.article.append(footer); ui.position();
    } catch (error) {
      if (current !== sequence || !host) return;
      ui.body.replaceChildren(element('p', error.message, 'error'));
      const retry = element('button', '重试', 'primary'); retry.addEventListener('click', () => explainSelection(capture));
      const settings = element('button', '打开设置'); settings.style.marginLeft = '10px'; settings.addEventListener('click', () => call({type: 'OPEN_APP', view: 'settings'}).catch(() => {}));
      ui.body.append(retry, settings); ui.position();
    }
  }
  function schedule(event) {
    if (!event.isTrusted || !enabled || event.composedPath().includes(host)) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      const capture = captureSelection();
      if (!capture) return;
      const signature = [capture.word, capture.sentence, capture.context].join('|');
      if (signature === lastSignature) return;
      lastSignature = signature;
      if (mode === 'auto') explainSelection(capture);
      else {
        const ui = show(capture); const button = element('button', '结合上下文解释', 'primary');
        button.addEventListener('click', () => explainSelection(capture)); ui.body.append(button); ui.position();
      }
    }, 650);
  }
  document.addEventListener('pointerup', schedule);
  document.addEventListener('keyup', event => {
    if (event.key === 'Escape') { hide(); return; }
    if (event.key === 'Shift' || event.key.startsWith('Arrow')) schedule(event);
  });
  document.addEventListener('pointerdown', event => {
    if (event.composedPath().includes(host)) return;
    clearTimeout(timer); lastSignature = ''; hide();
  });
  window.addEventListener('resize', () => repositionCurrent?.());
  window.addEventListener('scroll', event => {
    if (!host || event.composedPath().includes(host)) return;
    repositionCurrent?.();
  }, true);
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message.type === 'EXPLAIN_SELECTION') { enabled = true; explainSelection(captureSelection()); sendResponse({ok: true}); }
    if (message.type === 'STATUS') sendResponse({enabled});
    if (message.type === 'DISABLE') { enabled = false; clearTimeout(timer); hide(); sendResponse({ok: true}); }
    if (message.type === 'ENABLE') { enabled = true; updateSettings(); sendResponse({ok: true}); }
    if (message.type === 'SETTINGS_CHANGED') updateSettings();
  });
})();
