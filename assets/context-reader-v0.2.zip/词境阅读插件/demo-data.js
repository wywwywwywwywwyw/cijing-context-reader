export const DEMO_CONTEXT = 'To investigate, researcher Mina Patel interviewed both regular visitors and people who had recently stopped coming. This second group was important: asking only current users would exclude those whom the changes might have discouraged. Some former visitors said they could no longer find a sufficiently quiet place to concentrate.';
export const DEMO_SENTENCE = 'This second group was important: asking only current users would exclude those whom the changes might have discouraged.';
export const DEMO_EXPLANATION = {
  meaning: '第二个；这里表示「第二组人的」', partOfSpeech: '序数词',
  translation: '这第二组人很重要：如果只询问目前的使用者，就会把那些可能因这些变化而不再来的人排除在外。',
  explanation: 'second 修饰 group，表示前文提到的两组人中的第二组。这里没有时间或时长的意思，所以不能理解为「秒」。',
  reference: '第一组是 regular visitors（经常来的访客）；第二组是 people who had recently stopped coming（最近不再来的人）。This second group 指第二组。',
  memoryTip: 'a second 可以表示一秒；the second group 表示第二组。连同后面的名词一起理解。',
  uncertain: false
};
