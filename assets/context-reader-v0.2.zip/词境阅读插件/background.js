import {DEFAULT_SETTINGS, normalizeCapture, captureId, makeCard, reviewCard, parseExplanation, requestBody, validateImport} from './core.js';
import {DEMO_CONTEXT, DEMO_SENTENCE, DEMO_EXPLANATION} from './demo-data.js';

const protectedStorage = chrome.storage.local.setAccessLevel({accessLevel: 'TRUSTED_CONTEXTS'});
let writes = Promise.resolve();
const inflight = new Map();
function mutate(operation) {
  const result = writes.then(async () => {
    await protectedStorage;
    const {cards = {}} = await chrome.storage.local.get('cards');
    const value = await operation(cards);
    await chrome.storage.local.set({cards});
    return value;
  });
  writes = result.catch(() => {});
  return result;
}
async function settings() {
  await protectedStorage;
  const {settings = {}} = await chrome.storage.local.get('settings');
  return {...DEFAULT_SETTINGS, ...settings};
}
async function readCards() {
  await protectedStorage;
  await writes;
  return (await chrome.storage.local.get('cards')).cards || {};
}

async function explain(capture, config) {
  if (!config.apiKey) throw new Error('请先在词境设置中填写 DeepSeek API Key，或打开内置演示。');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST', headers: {'Content-Type': 'application/json', Authorization: `Bearer ${config.apiKey}`},
      body: JSON.stringify(requestBody(config, capture)), signal: controller.signal,
      credentials: 'omit', redirect: 'error'
    });
    if (!response.ok) {
      const errors = {400: '模型或请求设置不被接受，请检查模型名称。', 401: 'API Key 无效，请在设置中重新填写。',
        402: 'DeepSeek 账户余额不足，请检查账户。', 403: 'DeepSeek 拒绝了请求，请检查密钥权限。',
        429: '请求过于频繁，请稍后再试。', 500: 'DeepSeek 暂时无法处理请求，请稍后再试。', 503: 'DeepSeek 暂时繁忙，请稍后再试。'};
      throw new Error(errors[response.status] || `释义请求失败（${response.status}），请稍后再试。`);
    }
    const json = await response.json();
    return parseExplanation(json.choices?.[0]?.message?.content);
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('请求超过25秒，请稍后重试。');
    if (error instanceof TypeError) throw new Error('无法连接 DeepSeek，请检查网络后重试。');
    throw error;
  } finally { clearTimeout(timeout); }
}

async function lookup(raw, sender) {
  const capture = normalizeCapture({...raw, url: sender.tab ? sender.url : raw.url});
  const id = await captureId(capture);
  const cached = (await readCards())[id];
  if (cached && cached.provider === 'DeepSeek') {
    return mutate(cards => {
      const card = cards[id] || cached;
      cards[id] = {...card, lastSeen: Date.now(), encounters: card.encounters + 1};
      return {card: cards[id], cached: true, saved: true};
    });
  }
  if (inflight.has(id)) return inflight.get(id);
  const promise = (async () => {
    const config = await settings();
    const explanation = await explain(capture, config);
    const card = makeCard(id, capture, explanation, Date.now(), cached);
    try { await mutate(cards => { cards[id] = card; }); }
    catch { return {card, saved: false, warning: '释义成功，但本机保存失败。请先备份并整理词库后重试。'}; }
    return {card, cached: false, saved: true};
  })();
  inflight.set(id, promise);
  try { return await promise; } finally { inflight.delete(id); }
}

function trusted(sender) {
  return sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL(''));
}
const PRIVILEGED = new Set(['STATE', 'SETTINGS_SAVE', 'KEY_REMOVE', 'TEST', 'CARDS', 'REVIEW', 'DELETE', 'IMPORT', 'DEMO_SAVE']);
async function dispatch(message, sender) {
  if (!message || typeof message.type !== 'string' || sender.id !== chrome.runtime.id) throw new Error('请求无效。');
  if (PRIVILEGED.has(message.type) && !trusted(sender)) throw new Error('此操作仅能在扩展页面中完成。');
  switch (message.type) {
    case 'PUBLIC_SETTINGS': { const s = await settings(); return {lookupMode: s.lookupMode, hasKey: !!s.apiKey}; }
    case 'STATE': {
      const s = await settings(); const cards = Object.values(await readCards());
      return {model: s.model, lookupMode: s.lookupMode, hasKey: !!s.apiKey, count: cards.length, due: cards.filter(c => c.dueAt <= Date.now()).length};
    }
    case 'SETTINGS_SAVE': {
      const old = await settings(); const incoming = message.settings || {};
      const next = {...old, model: String(incoming.model || DEFAULT_SETTINGS.model).trim().slice(0, 100), lookupMode: incoming.lookupMode === 'button' ? 'button' : 'auto'};
      if (incoming.apiKey?.trim()) next.apiKey = String(incoming.apiKey).trim().slice(0, 1000);
      await chrome.storage.local.set({settings: next});
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) chrome.tabs.sendMessage(tab.id, {type: 'SETTINGS_CHANGED'}).catch(() => {});
      return {hasKey: !!next.apiKey};
    }
    case 'KEY_REMOVE': {
      const s = await settings(); delete s.apiKey; await chrome.storage.local.set({settings: s}); return {};
    }
    case 'TEST': return {explanation: await explain({word: 'second', sentence: DEMO_SENTENCE, context: DEMO_CONTEXT}, await settings())};
    case 'LOOKUP': return lookup(message.capture, sender);
    case 'CARDS': return Object.values(await readCards()).sort((a, b) => b.lastSeen - a.lastSeen);
    case 'REVIEW': return mutate(cards => {
      if (!cards[message.id]) throw new Error('这条记录已不存在。');
      cards[message.id] = reviewCard(cards[message.id], message.remembered === true);
      return cards[message.id];
    });
    case 'DELETE': return mutate(cards => { delete cards[message.id]; return {}; });
    case 'IMPORT': {
      const incoming = validateImport(message.payload);
      const identified = await Promise.all(incoming.map(async c => ({...c, id: await captureId(c)})));
      return mutate(cards => {
        let added = 0;
        for (const c of identified) if (!cards[c.id]) { cards[c.id] = c; added++; }
        return {added};
      });
    }
    case 'DEMO_SAVE': {
      const capture = {word: 'second', sentence: DEMO_SENTENCE, context: DEMO_CONTEXT, title: '词境内置演示', url: ''};
      const id = await captureId(capture);
      return mutate(cards => {
        if (cards[id]?.provider !== 'DeepSeek') cards[id] = makeCard(id, capture, DEMO_EXPLANATION, Date.now(), cards[id], '内置演示 · 非实时AI');
        return {card: cards[id], saved: true};
      });
    }
    case 'OPEN_APP': await chrome.tabs.create({url: chrome.runtime.getURL('app.html') + (message.view === 'settings' ? '#settings' : '#library')}); return {};
    default: throw new Error('未知操作。');
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  dispatch(message, sender).then(data => sendResponse({ok: true, data})).catch(error => sendResponse({ok: false, error: error.message || '操作失败，请重试。'}));
  return true;
});
chrome.runtime.onInstalled.addListener(async () => {
  await protectedStorage;
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({id: 'context-reader-explain', title: '词境：结合上下文解释「%s」', contexts: ['selection'], documentUrlPatterns: ['https://*/*', 'http://*/*']});
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'context-reader-explain' || !tab?.id) return;
  try {
    const target = {tabId: tab.id, frameIds: [info.frameId || 0]};
    await chrome.scripting.executeScript({target, files: ['content.js']});
    await chrome.tabs.sendMessage(tab.id, {type: 'EXPLAIN_SELECTION'}, {frameId: info.frameId || 0});
  } catch { await chrome.tabs.create({url: chrome.runtime.getURL('app.html#help')}); }
});
