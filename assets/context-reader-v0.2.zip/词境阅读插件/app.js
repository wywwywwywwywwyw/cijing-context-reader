import {getForgotStreak} from './core.js';
const $ = id => document.getElementById(id);
let cards = [], currentView = '', reviewId = null, toastTimer;
async function call(message) {
  const result = await chrome.runtime.sendMessage(message);
  if (!result?.ok) throw new Error(result?.error || '扩展没有响应，请重新打开此页面。');
  return result.data;
}
function node(tag, text, cls) { const el = document.createElement(tag); if (text !== undefined) el.textContent = text; if (cls) el.className = cls; return el; }
function toast(message, error = false) {
  $('global-status').textContent = message; $('global-status').hidden = false; $('global-status').classList.toggle('error', error);
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('global-status').hidden = true; }, 5000);
}
const run = fn => async (...args) => { try { await fn(...args); } catch (e) { toast(e.message, true); } };
function highlighted(card, cls = 'review-sentence') {
  const el = node('p', undefined, cls);
  const offset = Number.isInteger(card.selectionStart) ? card.selectionStart : card.sentence.toLowerCase().indexOf(card.word.toLowerCase());
  if (offset < 0) { el.textContent = card.sentence; return el; }
  el.append(document.createTextNode(card.sentence.slice(0, offset)), node('mark', card.sentence.slice(offset, offset + card.word.length)), document.createTextNode(card.sentence.slice(offset + card.word.length)));
  return el;
}
function renderExplanation(container, e) {
  container.append(node('p', e.meaning, 'meaning'));
  if (e.partOfSpeech) container.append(node('span', e.partOfSpeech, 'tag'));
  if (e.uncertain) container.append(node('p', '上下文可能不足，请结合原文核对。', 'muted'));
  for (const [label, text] of [['本句意思', e.translation], ['为什么这样理解', e.explanation], ['这里指的是', e.reference]]) {
    if (text) container.append(node('div', label, 'detail-label'), node('p', text, 'explanation-text'));
  }
  if (e.memoryTip) container.append(node('p', e.memoryTip, 'tip-box'));
}
function markForgotten(container, card) {
  const count = getForgotStreak(card);
  container.dataset.forgetLevel = Math.min(3, count);
  return count ? node('span', `连续未记住 × ${count}`, 'forget-badge') : null;
}
function dueCards() { return cards.filter(c => c.dueAt <= Date.now()).sort((a, b) => a.dueAt - b.dueAt); }
async function refresh() {
  cards = await call({type: 'CARDS'});
  $('nav-count').textContent = $('total-stat').textContent = cards.length;
  $('nav-due').textContent = $('due-stat').textContent = dueCards().length;
  $('reviewed-stat').textContent = cards.reduce((sum, c) => sum + c.reviews, 0);
  const state = await call({type: 'STATE'});
  $('connection-state').textContent = state.hasKey ? 'DeepSeek 已配置' : '先连接 DeepSeek';
  renderLibrary();
}
function renderLibrary() {
  const query = $('search').value.trim().toLowerCase(), filter = $('filter').value;
  const filtered = cards.filter(c => {
    const matches = [c.word, c.sentence, c.explanation.meaning, c.title].join(' ').toLowerCase().includes(query);
    return matches && (filter === 'all' || (filter === 'due' ? c.dueAt <= Date.now() : c.reviews > 0));
  });
  $('cards').replaceChildren(); $('empty-library').hidden = filtered.length > 0;
  $('forget-legend').hidden = !cards.some(card => getForgotStreak(card) > 0);
  $('empty-library').querySelector('h2').textContent = cards.length ? '暂时没有符合条件的语境。' : '从一个熟悉却没读懂的词开始。';
  for (const card of filtered) {
    const button = node('button', undefined, 'word-card'); button.type = 'button'; button.setAttribute('aria-label', `查看 ${card.word} 的语境`);
    const top = node('div', undefined, 'card-top'); top.append(node('h2', card.word), node('span', card.dueAt <= Date.now() ? '待复习' : '已安排', 'tag'));
    const bottom = node('div', undefined, 'card-bottom');
    const source = card.provider?.startsWith('内置') ? '内置演示' : (card.url ? new URL(card.url).hostname : '阅读记录');
    bottom.append(node('span', source), node('span', `遇到 ${card.encounters} 次`));
    button.append(top);
    const badge = markForgotten(button, card); if (badge) button.append(badge);
    button.append(node('p', card.explanation.meaning, 'meaning'), node('p', card.sentence, 'sentence-preview'), bottom);
    button.addEventListener('click', () => showDetail(card.id)); $('cards').append(button);
  }
}
function showDetail(id) {
  const card = cards.find(c => c.id === id); if (!card) return;
  const body = $('detail-body'); body.replaceChildren(node('div', card.provider || '语境释义', 'eyebrow'), node('h2', card.word, 'detail-word'), highlighted(card));
  const badge = markForgotten($('detail-dialog'), card); if (badge) body.prepend(badge);
  renderExplanation(body, card.explanation);
  const details = node('details'); details.append(node('summary', '查看保存的前后文'), node('p', card.context, 'review-context')); body.append(details);
  if (card.url) {
    const link = node('a', `原文：${card.title || card.url} ↗`, 'detail-source'); link.href = card.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; body.append(link);
  }
  const actions = node('div', undefined, 'detail-actions');
  const practice = node('button', '练习这张卡', 'secondary'); practice.addEventListener('click', () => {
    reviewId = id; $('detail-dialog').close(); if (location.hash === '#review') renderReview(); else location.hash = '#review';
  });
  const remove = node('button', '删除这条记录', 'quiet danger');
  remove.addEventListener('click', run(async () => {
    if (!confirm(`删除「${card.word}」在这段语境中的记录？`)) return;
    await call({type: 'DELETE', id}); $('detail-dialog').close(); await refresh(); toast('已删除这条语境记录。');
  }));
  actions.append(practice, remove); body.append(actions); $('detail-dialog').showModal();
}
function renderReview() {
  const queue = dueCards(); const card = cards.find(c => c.id === reviewId) || queue[0];
  $('review-count').textContent = `${queue.length} 条待复习`;
  const stage = $('review-stage'); stage.replaceChildren();
  if (!card) {
    const empty = node('div', undefined, 'empty'); empty.append(node('span', '✓', 'empty-symbol'), node('h2', '这轮复习完成了。'), node('p', '新遇到的词和到期的卡片，会在这里等你。'));
    const link = node('a', '回到语境本', 'primary button'); link.href = '#library'; empty.append(link); stage.append(empty); return;
  }
  reviewId = card.id;
  const article = node('article', undefined, 'review-card');
  article.append(node('span', card.provider?.startsWith('内置') ? '内置演示卡' : 'IN ITS ORIGINAL CONTEXT', 'eyebrow'), node('h2', card.word), highlighted(card));
  const badge = markForgotten(article, card); if (badge) article.insertBefore(badge, article.querySelector('.review-sentence'));
  const context = node('details'); context.append(node('summary', '需要前后文？'), node('p', card.context, 'review-context')); article.append(context);
  const answer = node('div', undefined, 'review-answer'); answer.hidden = true; renderExplanation(answer, card.explanation);
  const covered = node('div', '先想一想，这里的意思是什么？', 'review-hidden');
  const reveal = node('button', '揭晓释义', 'primary');
  const controls = node('div', undefined, 'review-controls'); controls.hidden = true;
  for (const [text, remembered, cls] of [['还没记住 · 10分钟后再练', false, 'secondary'], ['想起来了', true, 'primary']]) {
    const button = node('button', text, cls);
    button.addEventListener('click', run(async () => {
      for (const b of controls.querySelectorAll('button')) b.disabled = true;
      try { await call({type: 'REVIEW', id: card.id, remembered}); reviewId = null; await refresh(); renderReview(); }
      finally { for (const b of controls.querySelectorAll('button')) b.disabled = false; }
    })); controls.append(button);
  }
  reveal.addEventListener('click', () => { covered.hidden = reveal.hidden = true; answer.hidden = controls.hidden = false; });
  article.append(covered, reveal, answer, controls); stage.append(article);
}

async function showDemo() {
  const {card} = await call({type: 'DEMO_SAVE'});
  const container = $('demo-result'); container.replaceChildren(node('div', '内置演示 · 本次未调用 DeepSeek', 'eyebrow'), node('h2', 'second'));
  renderExplanation(container, card.explanation);
  container.append(node('p', '✓ 已自动存入语境本', 'status'));
  const practice = node('a', '去复习这张卡 →', 'secondary button'); practice.href = '#review'; practice.addEventListener('click', () => { reviewId = card.id; }); container.append(practice);
  await refresh();
}
$('demo-trigger').addEventListener('click', run(showDemo));
$('demo-text').addEventListener('pointerup', run(async () => {
  const s = window.getSelection(); if (s?.toString().trim().toLowerCase() !== 'second') return;
  if (!s.rangeCount || !$('demo-text').contains(s.getRangeAt(0).commonAncestorContainer)) return;
  await showDemo();
}));

async function loadSettings() {
  const state = await call({type: 'STATE'});
  $('model').value = state.model; $('lookup-mode').value = state.lookupMode;
  $('api-key').value = ''; $('api-key').placeholder = state.hasKey ? '已保存；留空则保留原密钥' : '粘贴你的 API Key';
  $('key-status').textContent = state.hasKey ? '密钥已保存在本机。不会显示原密钥，也不会包含在导出备份中。' : '密钥仅保存在扩展的本机设置中，不会写入导出备份。';
  $('remove-key').disabled = !state.hasKey;
  await loadSites();
}
async function loadSites() {
  const scripts = (await chrome.scripting.getRegisteredContentScripts()).filter(s => s.id.startsWith('site-'));
  $('site-list').replaceChildren();
  if (!scripts.length) $('site-list').append(node('p', '还没有自动启用的网站。', 'muted'));
  for (const script of scripts) {
    const pattern = script.matches[0]; const row = node('div', undefined, 'site-row');
    row.append(node('span', pattern.replace(/\/\*$/, '')));
    const remove = node('button', '取消自动启用', 'quiet');
    remove.addEventListener('click', run(async () => {
      await chrome.scripting.unregisterContentScripts({ids: [script.id]});
      const tabs = await chrome.tabs.query({url: pattern});
      for (const tab of tabs) await chrome.tabs.sendMessage(tab.id, {type: 'DISABLE'}).catch(() => {});
      // Required host grants cannot be removed; disabling the content-script registration still takes effect.
      const site = new URL(pattern);
      const required = (chrome.runtime.getManifest().host_permissions || []).some(p => {
        try { const host = new URL(p); return host.hostname === site.hostname && host.protocol === site.protocol; } catch { return false; }
      });
      if (!required) await chrome.permissions.remove({origins: [pattern]});
      await loadSites(); toast('已关闭此网站的自动选词。');
    })); row.append(remove); $('site-list').append(row);
  }
}
async function saveSettings() {
  const result = await call({type: 'SETTINGS_SAVE', settings: {apiKey: $('api-key').value, model: $('model').value, lookupMode: $('lookup-mode').value}});
  $('api-key').value = ''; await loadSettings();
  $('settings-status').textContent = result.hasKey ? '设置已保存。可以测试连接了。' : '设置已保存。填写密钥后可实时释义。';
  $('settings-status').classList.remove('error');
}
$('settings-form').addEventListener('submit', run(async event => { event.preventDefault(); await saveSettings(); await refresh(); }));
$('show-key').addEventListener('click', () => { const reveal = $('api-key').type === 'password'; $('api-key').type = reveal ? 'text' : 'password'; $('show-key').textContent = reveal ? '隐藏' : '显示'; });
$('test').addEventListener('click', async () => {
  $('test').disabled = true; $('settings-status').classList.remove('error');
  try {
    await saveSettings(); $('settings-status').textContent = '正在用 second 示例测试连接…';
    const result = await call({type: 'TEST'});
    $('settings-status').textContent = `连接成功 · second：${result.explanation.meaning}`;
  } catch (e) { $('settings-status').textContent = e.message; $('settings-status').classList.add('error'); }
  finally { $('test').disabled = false; }
});
$('remove-key').addEventListener('click', run(async () => { await call({type: 'KEY_REMOVE'}); await loadSettings(); await refresh(); $('settings-status').textContent = '密钥已移除，已保存的语境仍可复习。'; }));
$('search').addEventListener('input', renderLibrary); $('filter').addEventListener('change', renderLibrary);
$('detail-close').addEventListener('click', () => $('detail-dialog').close());
$('detail-dialog').addEventListener('click', event => { if (event.target === $('detail-dialog')) { const r = event.target.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) event.target.close(); } });
$('export').addEventListener('click', run(async () => {
  const data = {format: 'context-reader-v1', exportedAt: new Date().toISOString(), cards: await call({type: 'CARDS'})};
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'}));
  const link = node('a'); link.href = url; link.download = `词境备份-${new Date().toISOString().slice(0, 10)}.json`; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000); toast('已导出语境记录，不包含API密钥。');
}));
$('import-button').addEventListener('click', () => $('import-file').click());
$('import-file').addEventListener('change', run(async () => {
  const file = $('import-file').files[0]; $('import-file').value = ''; if (!file) return;
  if (file.size > 10 * 1024 * 1024) throw new Error('备份文件过大，请使用小于10MB的备份。');
  let payload; try { payload = JSON.parse(await file.text()); } catch { throw new Error('文件不是有效的JSON备份。'); }
  const result = await call({type: 'IMPORT', payload}); await refresh(); toast(`已导入 ${result.added} 条新语境，原有记录已保留。`);
}));
async function route() {
  const requested = location.hash.slice(1);
  const view = ['library', 'review', 'demo', 'settings', 'help'].includes(requested) ? requested : 'library';
  if (currentView !== view && view !== 'review') reviewId = null;
  currentView = view;
  for (const section of document.querySelectorAll('[data-view]')) section.hidden = section.dataset.view !== view;
  for (const a of document.querySelectorAll('[data-nav]')) { a.classList.toggle('active', a.dataset.nav === view); if (a.dataset.nav === view) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); }
  await refresh();
  if (view === 'settings') await loadSettings();
  if (view === 'review') renderReview();
}
window.addEventListener('hashchange', run(route));
window.addEventListener('focus', run(async () => { await refresh(); if (currentView === 'review' && !reviewId) renderReview(); }));
route().catch(e => toast(e.message, true));
