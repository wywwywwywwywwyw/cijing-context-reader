const $ = id => document.getElementById(id);
let tab;
function status(text, error = false) { $('popup-status').textContent = text; $('popup-status').classList.toggle('error', error); }
async function call(message) { const r = await chrome.runtime.sendMessage(message); if (!r.ok) throw new Error(r.error); return r.data; }
async function registrationId(origin) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(origin));
  return 'site-' + Array.from(new Uint8Array(bytes).slice(0, 10), b => b.toString(16).padStart(2, '0')).join('');
}
async function init() {
  [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  const state = await call({type: 'STATE'});
  $('count').textContent = state.count; $('due').textContent = state.due;
  if (!tab?.url || !/^https?:\/\//.test(tab.url)) {
    $('site-name').textContent = '请先打开一个普通英文网页。'; $('enable').disabled = true; $('remember').disabled = true;
  } else {
    $('site-name').textContent = new URL(tab.url).hostname;
    try {
      const r = await chrome.tabs.sendMessage(tab.id, {type: 'STATUS'});
      if (r?.enabled) { $('enable').textContent = '选词已启用'; $('pause').hidden = false; }
    } catch {}
  }
  if (!state.hasKey) status('先在设置中填写 DeepSeek API Key，即可实时释义。');
}
$('enable').addEventListener('click', async () => {
  if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) return;
  $('enable').disabled = true;
  try {
    if ($('remember').checked) {
      const origin = new URL(tab.url).origin + '/*';
      const allowed = await chrome.permissions.request({origins: [origin]});
      if (!allowed) throw new Error('未获得网站权限。取消勾选“下次自动启用”可仅在本次网页使用。');
      const id = await registrationId(origin);
      const existing = await chrome.scripting.getRegisteredContentScripts({ids: [id]});
      if (!existing.length) await chrome.scripting.registerContentScripts([{id, matches: [origin], js: ['content.js'], runAt: 'document_idle', persistAcrossSessions: true}]);
    }
    await chrome.scripting.executeScript({target: {tabId: tab.id}, files: ['content.js']});
    await chrome.tabs.sendMessage(tab.id, {type: 'ENABLE'});
    $('enable').textContent = '选词已启用'; $('pause').hidden = false;
    status('回到正文，选中一个英文单词即可。');
  } catch (error) { status(error.message || '此页面不允许扩展运行，请换一个普通网页。', true); }
  finally { $('enable').disabled = false; }
});
$('pause').addEventListener('click', async () => {
  try { await chrome.tabs.sendMessage(tab.id, {type: 'DISABLE'}); $('pause').hidden = true; $('enable').textContent = '在当前网页启用选词'; status('当前网页已暂停；刷新后会恢复网站设置。'); }
  catch (e) { status(e.message, true); }
});
for (const id of ['library', 'settings']) $(id).addEventListener('click', () => chrome.tabs.create({url: chrome.runtime.getURL(`app.html#${id}`)}));
init().catch(e => status(e.message, true));
